#ifndef __CAMERA_H
#define __CAMERA_H
#include "System.h"
#include "zf_device_mt9v03x.h"

//�������ͽṹ��
struct YUAN_SU{
     int16 Ramp;                   //�µ�
     int16 barrier;                //���
     int16 straight;               //ֱ��
     int16 bend;                   //���
     int16 Cross;                  //ʮ��
     int16 R_Cross;                //ʮ��(������Ҫ��������)
     int16 L_Cross;                //ʮ��(������Ҫ��������)
     int16 LeftCirque;             //�󻷵�
     int16 RightCirque;            //�һ���
     int16 Barn_l_out;             //�����
     int16 Barn_r_out;             //���ҿ�
     int16 Barn_l_in;              //�����
     int16 Barn_r_in;              //���ҿ�
     int16 Open_road;              //��·
};
extern struct YUAN_SU road_type;
    

extern uint8 image_yuanshi[MT9V03X_H][MT9V03X_W];
extern uint8 image_01[MT9V03X_H][MT9V03X_W];
extern uint8 Threshold;
extern uint8 search_line_end;
extern uint8 l_lose_value, r_lose_value;
extern uint8 chang_point_l,chang_point_r;

extern int16 l_line_x[MT9V03X_H], r_line_x[MT9V03X_H], m_line_x[MT9V03X_H];  //����ԭʼͼ������ұ߽������

extern uint8 l_search_flag[MT9V03X_H], r_search_flag[MT9V03X_H];                   //�Ƿ��ѵ��ߵı�־
extern uint8 l_width, r_width;                                                     //ѭ��������
extern uint8 l_search_start, r_search_start;                                       //������ʼx����
extern uint8 l_line_x_yuanshi[MT9V03X_H], r_line_x_yuanshi[MT9V03X_H];
extern uint8 r_losemax, l_losemax;
extern uint8 road_width[MT9V03X_H];




extern int32 offset_1;  //����ͷ�����õ���ƫ��
extern float offset;    //����ͷ�����õ���ƫ��
extern uint8 flag_stop;

extern uint8 length_l, length_r;

extern uint8 qianzhang;
extern uint8 qianzhang_l;
extern uint8 qianzhang_r;


extern uint8 flag_starting_line;
extern uint8 black_blocks_l, black_blocks_r;
extern uint8 cursor_l, cursor_r;

extern uint8 l_lose_num, r_lose_num ;  //�ض���Χ�����Ҷ�����
extern unsigned char L_Monotonic_Num,R_Monotonic_Num;
extern int16 Cross_Conner;
extern int16 OpendRoad_Distance,OpendRoad_Time,OpendRoad_Conner;
extern uint8 Change_point;



/***ʱ���������***/
extern uint32  u32InKu_Time;  //����ʱ
extern uint32 u32Barrier_Time;  //��ϼ�ʱ







extern int OFFSET0, OFFSET1, OFFSET2;

void Camera_All_Deal(void);
void Transfer_Camera(uint8 * p, uint8 *q, int16 pixel_num);
void Get01change_Dajin(void);
uint8 Threshold_Deal(uint8* image, uint16 col, uint16 row, uint32 pixel_threshold);
void Pixle_Filter(void);
void Search_Line(void);
void Calculate_Offset(void);
void Blacking(void);
void Outside_protect(void);
void Seek_Road (void);
uint8 search_Line_point_num(uint8 type,uint8 line);


void Check_Bianxian(uint8 type);
void QianZhang(uint8 type);
void search_guai_point(uint8 start_line,uint8 end_line);
uint16 Check_Cirque(uint8 type, uint8 startline);
void Check_Starting_Line(uint8 start_point, uint8 end_point, uint8 qiangdu);
void Count_Lose_Line_Num(unsigned char start_h,unsigned char end_h);

unsigned char  RoadSide_Monotonic (unsigned char X1, unsigned char X2, int16 imageIn[MT9V03X_H],float intensity);
extern uint16 u16Block_White_Num;
void Fine_Block_Num(unsigned char start_x,unsigned char start_y,unsigned char end_x,unsigned char end_y);
void La_Zhixian(int16 x_down, int16 y_down, int16 x_up, int16 y_up, int16 *array) ;
void search_stopline(uint8 hang);
void image_CBH(uint8 Data[MT9V03X_H][MT9V03X_W], int16 Threshold_cbh);

void Element_Test(void);
void  Element_Start_Handle(void);
void  Element_Final_Handle(void);



















#endif

