#ifndef _GPS_FLASH_H_
#define _GPS_FLASH_H_
#include "zf_common_headfile.h"
#include "PLATFORM_TYPES.H"
#include "zf_common_typedef.h"

extern void flash_tran(uint32* GPS_temp,double*GPS,uint8 size);
extern void flash_tran1(uint32* GPS_temp,double*GPS,uint8 size);

extern void flash_read(uint32* GPS_temp,double*GPS,uint8 size);
extern void flash_read1(uint32* GPS_temp,double*GPS,uint8 size);

#endif
