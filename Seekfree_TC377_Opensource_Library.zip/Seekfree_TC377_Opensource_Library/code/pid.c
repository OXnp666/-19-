/*
 * pid.c
 *
 *  Created on: 2023��11��18��
 *      Author: 21035
 */

#include "pid.h"

tPid X_Balance,Y_Balance,X_Velocity,Y_Velocity;

void Pid_Init(double xb_p,double xb_i,double xb_d,double yb_p,double yb_i,double yb_d,double yv_p,double yv_i)
{
    X_Balance.Kp=xb_p; //-2500
    X_Balance.Ki=xb_i;
    X_Balance.Kd=xb_d; //-150
    X_Velocity.Kp=0;
    X_Velocity.Ki=0;

    Y_Balance.Kp=-yb_p;//-400
    Y_Balance.Ki=-yb_i;
    Y_Balance.Kd=-yb_d;//-25
    Y_Velocity.Kp=-yv_p;//-yv_p
    Y_Velocity.Ki=-yv_i;//-yv_i
}

float x_balance(float Angle,float Angle_Zero,float Gyro)
{
    float PWM,Bias;
    static float error;
    Bias=Angle-Angle_Zero;                                              //��ȡƫ��
    error+=Bias;                                                         //ƫ���ۻ�
    error = constrain_float(error, -120, 120);                            //�����޷�
    PWM=X_Balance.Kp*Bias + X_Balance.Ki*error + Gyro*X_Balance.Kd/10;   //��ȡ������ֵ
    PWM = constrain_float(PWM, -8000, 8000);                            //����޷�

    return PWM;
}

float y_balance(float Angle,float Angle_Zero,float Gyro)
{
    float PWM,Bias;
    static float error;
    Gyro = constrain_float(Gyro, -3000, 3000);                            //ȡֵ�޷�
    Bias=Angle-Angle_Zero;                                               //��ȡƫ�ƫ��ֵ��Ҫ���¼��㣬��Ȼ�������䣩
    error+=Bias;                                                         //ƫ���ۻ�
    error = constrain_float(error, -30, 30);                            //�����޷�
    PWM=Y_Balance.Kp*Bias + Y_Balance.Ki*error + Gyro*Y_Balance.Kd/10;   //��ȡ������ֵ
    PWM = constrain_float(PWM, -9000, 9000);

    return PWM;
}

float x_velocity(int encoder,int encoder_zero)
{
    static float Encoder,Encoder_Integral;
    float Velocity,Encoder_Least,encoder_err;

    encoder_err=(float)(encoder-encoder_zero);
    Encoder_Integral+=encoder_err;

//    Encoder_Least = (float)encoder;                                                   //�ٶ��˲�
//    Encoder *= 0.7;                                                              //һ�׵�ͨ�˲���
//    Encoder += Encoder_Least*0.3;                                                //һ�׵�ͨ�˲���
//    Encoder_Integral += Encoder;
    Encoder_Integral = constrain_float(Encoder_Integral, -2600, 2600);        //�����޷�
    Velocity = Encoder * X_Velocity.Kp + Encoder_Integral * X_Velocity.Ki/100; //��ȡ������ֵ
    Velocity = constrain_float(Velocity, -5000, 5000);

    return Velocity;
}

float y_velocity(int encoder,int encoder_zero)
{
    static float Encoder,Encoder_Integral;
    float Velocity,Encoder_Least,encoder_err;

    encoder_err=(float)(encoder-encoder_zero);
    Encoder_Integral+=encoder_err;

//    Encoder_Least = (float)encoder;                                  //�ٶ��˲�
//    Encoder *= 0.7;                                                            //һ�׵�ͨ�˲���
//    Encoder += Encoder_Least*0.3;                                              //һ�׵�ͨ�˲���
//    Encoder_Integral += Encoder - encoder_zero;

    Encoder_Integral = constrain_float(Encoder_Integral, -2000, 2000);        //�����޷�
    Velocity = encoder_err * Y_Velocity.Kp + Encoder_Integral * Y_Velocity.Ki;   //��ȡ������ֵ
    return Velocity;
}


float constrain_float (float amt, float low, float high)
{
    if(amt<low)amt=low;
    if(amt>high)amt=high;

    return amt;
}

int constrain_int(int amt, int low, int high)
{
    return ((amt)<(low)?(low):((amt)>(high)?(high):(amt)));
}

int emergency_stop (float real_roll,float pitch,float real_pitch,float roll)
{
    int state=1;
    if(real_roll>pitch||real_roll<-pitch){state=0;}
    if(real_pitch >roll||real_pitch <-roll){state=0;}
    return state;
}
