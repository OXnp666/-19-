/*
 * all_data.h
 *
 *  Created on: 2023��11��17��
 *      Author: 21035
 */

#ifndef CODE_ALL_DATA_H_
#define CODE_ALL_DATA_H_

#define DEBUG 0 //ʹ�ܵ���
#define GPS   1 //ʹ��GPS
#define CAS   1 //ʹ�ܶ����ִ���pid
#define USE_IMU 1 //ʹ��IMU������
#define PAPER 1   //ʹ��paper�����ǽ���
#define NAV_GET 1 //ʹ��ң�عߵ��ɵ�

extern volatile unsigned  int SysTick_count;

typedef struct{
    signed short int accX;
    signed short int accY;
    signed short int accZ;
    signed short int gyroX;
    signed short int gyroY;
    signed short int gyroZ;
}_st_Mpu;

typedef struct{
    signed short int magX;
    signed short int magY;
    signed short int magZ;
}_st_Mag;

typedef struct{
    double roll;
    double pitch;
    double yaw;
    double IMU_yaw;
}_st_AngE;

typedef struct{
    int left;
    int right;
    int stand;
}_st_Encoder;

typedef struct{
    double turn_error;
    double run_speed;
    double target_speed;
    double target_error;
    double set_speed;
}_st_Car;

typedef struct{
    double roll;
    double pitch;
    double yaw;
    double encoder;
    double error;
    double dynamic; //��̬���
}_st_Zero;

typedef struct{
    float x;
    float y;
    float z;
    float left;
    float right;
    float death;
}_st_Motor;

typedef struct{
    double x;
    double y;
    double dir;
    double ang;
    double dis;
    double error;
    double longitude[20];
    double latitude[20];
    uint32 target_x[100];
    uint32 target_y[100];
    uint8 run_flag;
    uint8 stop_flag;
    uint8 point_cnt;
    uint8 input_cnt;
    uint8 output_cnt;
}_st_RTK;

typedef struct{
    double ang;
    double target_ang[20];
    double error;
    double error_sum;
    uint8 run_flag;
    uint8 stop_flag;
    uint8 tof_flag;
    uint8 turn_flag;
    uint8 point_cnt;
    uint8 input_cnt;
    uint8 output_cnt;
    uint8 mode;
    uint32 target_a[100];
    uint32 target_b[100];
    uint16 tof;
}_st_IMU;

typedef struct{
    double start_yaw;
    double cur_yaw;
    double update_yaw;
    double update_yaw_total;
    double update_yaw_old;
    double x_cur;
    double y_cur;
    double x_set;   //mm
    double y_set;   //mm
    double error;
    double target_x[100];
    double target_y[100];
    uint32 target_a[100];
    uint32 target_b[100];
    uint8 input;
    uint8 output;
    uint8 start_flag;
    uint8 track_flag;
    uint8 get_flag;
    uint8 flag_2s;
}_st_Nav;

typedef struct{
    uint16 motor;
    uint16 gyrox,roll,speed;
    uint16 gyroy,pitch,encoder;
    uint16 gyroz,yaw,error;
    uint16 tof,turn;
    uint8 read1,read2,read3,read4,read5,read6;
}_st_Tick;

typedef struct{
    uint8 point[20];
    uint8 input_cnt;
    uint8 output_cnt;
}_st_Board;

typedef struct{
    double roll_kp;
    double gyroy_kp;
    double imu_kp;
    double rtk_kp;
    double img_kp;
    float limit_goki;
}_st_Pid;

//extern _st_Remote Remote;
extern _st_Mpu ICM20602;
extern _st_Mag AK8975; //����������Ӵ�����
extern _st_AngE Angle;
extern _st_Encoder Encoder;

extern _st_Car Car;
extern _st_Zero Zero;
extern _st_Motor Motor;
extern _st_RTK RTK;
extern _st_IMU IMU;
extern _st_Nav Nav;
extern _st_Tick Tick;
extern _st_Board Board;
extern _st_Pid SetPid;

extern uint8 serial_flag,fifo_get_data[1000];
extern uint8 key_flag,key_num,button,track,ima_track_mode,ima_flag;
extern int32 set_init[50];
extern double n[100];

#endif /* CODE_ALL_DATA_H_ */
