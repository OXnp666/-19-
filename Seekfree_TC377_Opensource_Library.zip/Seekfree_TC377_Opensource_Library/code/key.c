/*
 * key.c
 *
 *  Created on: 2023��11��27��
 *      Author: 21035
 */
#include "key.h"

void mykey_init(void)
{
    gpio_init(P22_0,GPI,0,GPO_PUSH_PULL);
    gpio_init(P22_1,GPI,0,GPO_PUSH_PULL);
    gpio_init(P22_2,GPI,0,GPO_PUSH_PULL);
    gpio_init(P22_3,GPI,0,GPO_PUSH_PULL);

    pit_ms_init(CCU61_CH0, 1);
}


#define  KEY_ONE_READ           gpio_get_level(P22_3)
#define  KEY_TWO_READ           gpio_get_level(P22_0)
#define  KEY_THREE_READ         gpio_get_level(P22_1)
#define  KEY_FOUR_READ          gpio_get_level(P22_2)
#define  KEY_ANY_DOWN           KEY_ONE_READ == 0 || KEY_TWO_READ == 0 || KEY_THREE_READ == 0 || KEY_FOUR_READ == 0
#define  KEY_ALL_UP             KEY_ONE_READ == 1 && KEY_TWO_READ == 1 && KEY_THREE_READ == 1 && KEY_FOUR_READ == 1

typedef enum
{
    FSM_KEY_Up       ,//��������
    FSM_KEY_DownSnake,//���¶���
    FSM_KEY_Down     ,//��������
    FSM_KEY_UpSnake  ,//���𶶶�
}FSM_state_t;

typedef struct
{
    FSM_state_t state;     //״̬��״̬
    uint8_t volatile cnt;  //״̬��������
    uint8_t auxiliary_flag;//״̬��������־λ
    uint16_t auxiliary_cnt;//״̬��������ʱ��
    uint8_t press_flag;    //״̬��������־λ
    uint8_t KEY_Up_flag;   //�Ƿ������־λ
}FSM_value_t;

typedef enum
{
    KEY_NULL,
    KEY_ONE,
    KEY_TWO,
    KEY_THREE,
    KEY_FOUR
}KEY_id_t;

typedef enum
{
    KEY_Event_NULL,
    KEY_Event_Click,
    KEY_Event_DoubleClick,
    KEY_Event_Press,
}KEY_event_t;

typedef struct
{
    KEY_id_t id;
    KEY_event_t event;

}KEY_which_t;
FSM_value_t FSM_value = {FSM_KEY_Up,0,0,0,0};
KEY_which_t KEY_which = {0,0};

void key_scan(void)
{
    if(FSM_value.cnt >= 5)
    {
        FSM_value.cnt = 0;
        switch(FSM_value.state)
        {
            case FSM_KEY_Up://��������
            {
                if(FSM_value.auxiliary_flag)//����������¹�
                {
                    //���¼�ֵ
                    KEY_which.id = FSM_value.auxiliary_flag;
                    if(FSM_value.auxiliary_cnt > 500)KEY_which.event = KEY_Event_Press;
                    else KEY_which.event = KEY_Event_Click;

                    FSM_value.auxiliary_flag = 0;
                    FSM_value.press_flag = 0;
                }
                if(KEY_ANY_DOWN)FSM_value.state = FSM_KEY_DownSnake;//����һ���������£��л�������״̬
                break;
            }
            case FSM_KEY_DownSnake://���¶���״̬
            {
             if(KEY_ANY_DOWN)FSM_value.state = FSM_KEY_Down;//�л�������״̬
             else FSM_value.state = FSM_KEY_Up;//�л�������״̬
             break;
            }
            case FSM_KEY_Down: //��������״̬
            {
                if(KEY_ANY_DOWN)
                {
                    if(FSM_value.press_flag == 0)
                    {
                        FSM_value.auxiliary_cnt = 0;//״̬��������������ʼ����
                        FSM_value.press_flag = 1;//��ֹ����ֵ������

                    }
                    //����״̬��������־λ
                    if(KEY_ONE_READ == 0)FSM_value.auxiliary_flag = KEY_ONE;
                    if(KEY_TWO_READ == 0)FSM_value.auxiliary_flag = KEY_TWO;
                    if(KEY_THREE_READ == 0)FSM_value.auxiliary_flag = KEY_THREE;
                    if(KEY_FOUR_READ == 0)FSM_value.auxiliary_flag = KEY_FOUR;
                }
                if(KEY_ALL_UP)FSM_value.state = FSM_KEY_UpSnake; //�л������𶶶�״̬
                break;
            }
            case FSM_KEY_UpSnake:
            {
                if(KEY_ALL_UP)FSM_value.state = FSM_KEY_Up;//�л�������״̬
                break;
            }
            default: FSM_value.state = FSM_KEY_Up;
        }
    }
}

uint8 key_read(void)
{
    key_scan();

    uint8 key_value=0;

    if(KEY_which.id == KEY_ONE&& KEY_which.event == KEY_Event_Click)//�жϼ�ֵ����Ϊ����״̬
    {
        key_value=1;
        KEY_which.id = KEY_NULL;//�ظ���ֵΪȱʡֵ
        KEY_which.event = KEY_Event_NULL;
    }
    else if(KEY_which.id == KEY_ONE&& KEY_which.event == KEY_Event_Press)
    {
        key_value=6;
        KEY_which.id = KEY_NULL;
        KEY_which.event = KEY_Event_NULL;
    }
    else if(KEY_which.id == KEY_TWO)
    {
        key_value=2;
        KEY_which.id = KEY_NULL;
        KEY_which.event = KEY_Event_NULL;
    }
    else if(KEY_which.id == KEY_THREE)
    {
        key_value=3;
        KEY_which.id = KEY_NULL;
        KEY_which.event = KEY_Event_NULL;
    }
    else if(KEY_which.id == KEY_FOUR&& KEY_which.event == KEY_Event_Click)
    {
        key_value=4;
        KEY_which.id = KEY_NULL;
        KEY_which.event = KEY_Event_NULL;
    }
    else if(KEY_which.id == KEY_FOUR&& KEY_which.event == KEY_Event_Press)
    {
        key_value=5;
        KEY_which.id = KEY_NULL;
        KEY_which.event = KEY_Event_NULL;
    }
    return key_value;
}

IFX_INTERRUPT(cc61_pit_ch0_isr, CCU6_1_CH0_INT_VECTAB_NUM, CCU6_1_CH0_ISR_PRIORITY)
{
    interrupt_global_enable(0);                     // �����ж�Ƕ��
    pit_clear_flag(CCU61_CH0);

    if(++FSM_value.cnt > 254)FSM_value.cnt = 0;
    if(++FSM_value.auxiliary_cnt == 65534)FSM_value.auxiliary_cnt = 0;//״̬�����������ָ�Ϊȱʡ
}


