/*
 * icm.c
 *
 *  Created on: 2023��11��17��
 *      Author: 21035
 */
#include "zf_common_headfile.h"
#include "icm.h"

static float NormAcc;
_st_Mpu ICM20602;   //MPU6050ԭʼ����
_st_AngE Angle;    //��ǰ�Ƕ���ֵ̬
_st_Encoder Encoder;
int16_t MpuOffset[6] = {0};
static volatile int16 *pMpu = (int16 *)&ICM20602;
float my_pitch=0,my_roll=0,my_raw=0;
float values[10];
typedef volatile struct {
  float q0;
  float q1;
  float q2;
  float q3;
} Quaternion;


void IcmGetData(void) //��ȡ���������ݼ��˲�
{
    uint8_t i;
    uint16 k[6];

#if USE_IMU
    imu660ra_get_acc();
    imu660ra_get_gyro();
    k[0]=imu660ra_acc_x;
    k[1]=imu660ra_acc_y;
    k[2]=imu660ra_acc_z;
    k[3]=imu660ra_gyro_x;
    k[4]=imu660ra_gyro_y;
    k[5]=imu660ra_gyro_z;
#else
    icm20602_get_acc();
    icm20602_get_gyro();
    k[0]=icm20602_acc_x;
    k[1]=icm20602_acc_y;
    k[2]=icm20602_acc_z;
    k[3]=icm20602_gyro_x;
    k[4]=icm20602_gyro_y;
    k[5]=icm20602_gyro_z;
#endif

    for(i=0;i<6;i++)
    {
        pMpu[i] = k[i]-MpuOffset[i];
        if(i < 3)
        {
            {
                static struct _1_ekf_filter ekf[3] = {{0.02,0,0,0,0.001,0.543},{0.02,0,0,0,0.001,0.543},{0.02,0,0,0,0.001,0.543}};
                kalman_1(&ekf[i],(float)pMpu[i]);  //һά������
                pMpu[i] = (int16_t)ekf[i].out;
            }
        }
        if(i > 2)
        {
            uint8_t k=i-3;
            const float factor = 0.15f;  //�˲�����
            static float tBuff[3];

            pMpu[i] = tBuff[k] = tBuff[k] * (1 - factor) + pMpu[i] * factor;
        }
    }
}

void IcmGetOffset(void) //У׼
{
    int32_t buffer[6]={0};
    int16_t i;
    uint8_t k=30;
    const int8_t MAX_GYRO_QUIET = 5;
    const int8_t MIN_GYRO_QUIET = -5;
/*           wait for calm down                                                               */
    int16_t LastGyro[3] = {0};
    int16_t ErrorGyro[3];
    /*           set offset initial to zero         */

    memset(MpuOffset,0,12);
    MpuOffset[2] = 8192;   //set offset from the 8192

//    TIM_ITConfig(  //ʹ�ܻ���ʧ��ָ����TIM�ж�
//        TIM2, //TIM2
//        TIM_IT_Update ,
//        DISABLE  //ʹ��
//        );
    while(k--)
    {
        do
        {
            system_delay_10ns(1);
            IcmGetData();
            for(i=0;i<3;i++)
            {
                ErrorGyro[i] = pMpu[i+3] - LastGyro[i];
                LastGyro[i] = pMpu[i+3];
            }
        }while ((ErrorGyro[0] >  MAX_GYRO_QUIET )|| (ErrorGyro[0] < MIN_GYRO_QUIET)
                    ||(ErrorGyro[1] > MAX_GYRO_QUIET )|| (ErrorGyro[1] < MIN_GYRO_QUIET)
                    ||(ErrorGyro[2] > MAX_GYRO_QUIET )|| (ErrorGyro[2] < MIN_GYRO_QUIET)
                        );
    }

/*           throw first 100  group data and make 256 group average as offset                    */
    for(i=0;i<356;i++)
    {
        IcmGetData();
        if(100 <= i)
        {
            uint8_t k;
            for(k=0;k<6;k++)
            {
                buffer[k] += pMpu[k];
            }
        }
    }

    for(i=0;i<6;i++)
    {
        MpuOffset[i] = buffer[i]>>8;
    }
//    TIM_ITConfig(  //ʹ�ܻ���ʧ��ָ����TIM�ж�
//        TIM2, //TIM2
//        TIM_IT_Update ,
//        ENABLE  //ʹ��
//        );
}

void IcmGetAngle(const _st_Mpu *pMpu,_st_AngE *pAngE, float dt)
{
    volatile struct V{
                float x;
                float y;
                float z;
                } Gravity,Acc,Gyro,AccGravity;

    static struct V GyroIntegError = {0};
    static  float KpDef = 0.8f ;
    static  float KiDef = 0.0003f;
    static Quaternion NumQ = {1, 0, 0, 0};
    float q0_t,q1_t,q2_t,q3_t;
  //float NormAcc;
    float NormQuat;
    float HalfTime = dt * 0.5f;



    // ��ȡ��Ч��ת�����е���������
    Gravity.x = 2*(NumQ.q1 * NumQ.q3 - NumQ.q0 * NumQ.q2);
    Gravity.y = 2*(NumQ.q0 * NumQ.q1 + NumQ.q2 * NumQ.q3);
    Gravity.z = 1-2*(NumQ.q1 * NumQ.q1 + NumQ.q2 * NumQ.q2);
    // ���ٶȹ�һ��
    NormAcc = Q_rsqrt(squa(ICM20602.accX)+ squa(ICM20602.accY) +squa(ICM20602.accZ));

    Acc.x = pMpu->accX * NormAcc;
    Acc.y = pMpu->accY * NormAcc;
    Acc.z = pMpu->accZ * NormAcc;
    //������˵ó���ֵ
    AccGravity.x = (Acc.y * Gravity.z - Acc.z * Gravity.y);
    AccGravity.y = (Acc.z * Gravity.x - Acc.x * Gravity.z);
    AccGravity.z = (Acc.x * Gravity.y - Acc.y * Gravity.x);
    //�������ٶȻ��ֲ������ٶȵĲ���ֵ
    GyroIntegError.x += AccGravity.x * KiDef;
    GyroIntegError.y += AccGravity.y * KiDef;
    GyroIntegError.z += AccGravity.z * KiDef;
    //���ٶ��ںϼ��ٶȻ��ֲ���ֵ
    Gyro.x = pMpu->gyroX * Gyro_Gr + KpDef * AccGravity.x  +  GyroIntegError.x;//������
    Gyro.y = pMpu->gyroY * Gyro_Gr + KpDef * AccGravity.y  +  GyroIntegError.y;
    Gyro.z = pMpu->gyroZ * Gyro_Gr + KpDef * AccGravity.z  +  GyroIntegError.z;
    // һ�����������, ������Ԫ��

    q0_t = (-NumQ.q1*Gyro.x - NumQ.q2*Gyro.y - NumQ.q3*Gyro.z) * HalfTime;
    q1_t = ( NumQ.q0*Gyro.x - NumQ.q3*Gyro.y + NumQ.q2*Gyro.z) * HalfTime;
    q2_t = ( NumQ.q3*Gyro.x + NumQ.q0*Gyro.y - NumQ.q1*Gyro.z) * HalfTime;
    q3_t = (-NumQ.q2*Gyro.x + NumQ.q1*Gyro.y + NumQ.q0*Gyro.z) * HalfTime;

    NumQ.q0 += q0_t;
    NumQ.q1 += q1_t;
    NumQ.q2 += q2_t;
    NumQ.q3 += q3_t;
    // ��Ԫ����һ��
    NormQuat = Q_rsqrt(squa(NumQ.q0) + squa(NumQ.q1) + squa(NumQ.q2) + squa(NumQ.q3));
    NumQ.q0 *= NormQuat;
    NumQ.q1 *= NormQuat;
    NumQ.q2 *= NormQuat;
    NumQ.q3 *= NormQuat;


        // ��Ԫ��תŷ����
    {

            #ifdef  YAW_GYRO
            *(float *)pAngE = atan2f(2 * NumQ.q1 *NumQ.q2 + 2 * NumQ.q0 * NumQ.q3, 1 - 2 * NumQ.q2 *NumQ.q2 - 2 * NumQ.q3 * NumQ.q3) * RtA;  //yaw
            #else
#if !PAPER
                float yaw_G = pMpu->gyroZ * Gyro_G;
                if((yaw_G > 3.0f) || (yaw_G < -3.0f)) //����̫С������Ϊ�Ǹ��ţ�����ƫ������
                {
                    pAngE->yaw  += yaw_G * dt;
                }
#endif
            #endif
            pAngE->pitch  =  asin(2 * NumQ.q0 *NumQ.q2 - 2 * NumQ.q1 * NumQ.q3) * RtA;

            pAngE->roll = atan2(2 * NumQ.q2 *NumQ.q3 + 2 * NumQ.q0 * NumQ.q1, 1 - 2 * NumQ.q1 *NumQ.q1 - 2 * NumQ.q2 * NumQ.q2) * RtA;  //PITCH
    }
}

/***************************************************END OF FILE***************************************************/






