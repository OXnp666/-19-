/*
 * serial.c
 *
 *  Created on: 2023��11��20��
 *      Author: 21035
 */
#include "serial.h"

//int Rxdata(char *str)
//{
//    char *loc,*token;
//    int a;
//
//    loc = strstr((char*)fifo_get_data,str);
//    token = strtok(loc,str);
//    a = atoi((char*)token);
//
//    return a;
//}


////���ݽ���
//void analysis(char *a)
//{
//    int len=strlen(a),i,j,count=0,cnt=0,wei[20],num[10]={0};
//    bool ctoi=0,befctoi=0;
//    for(i=0;i<len+1;i++)
//    {
//        if(a[i]>='0'&&a[i]<='9')
//        {
//            ctoi=1;
//        }
//        else
//        {
//            ctoi=0;
//        }
//        if(befctoi==0&&ctoi==1)//������
//        {
//            wei[count]=a[i]-'0';
//            befctoi=1;
//            count++;
//        }
//        else if(befctoi==1&&ctoi==1)//��λ
//        {
//            wei[count]=a[i]-'0';
//            count++;
//        }
//        else if(befctoi==1&&ctoi==0)//�½���
//        {
//            for(j=0;j<count;j++)
//            {
//                num[cnt]+=wei[j]*pow(10,(double)(count-j-1));
//            }
//            cnt++;
//            befctoi=0;
//            count=0;
//        }
//    }
//
//    for(i=0;i<cnt;i++)
//    {
//        printf("a[%d]=%d",i,num[i]);
//    }
//}

void analysis(char *a,double *number)
{
    int len = strlen(a), i, j, count = 0, wei[20], times = 0,dot=0;
    double num[10] = {0};
    bool ctoi = 0, befctoi = 0, hasDecimal = 0 ,flag = 0;
    for (i = 0; i < len + 1; i++)
    {
        if (a[i]>='0'&&a[i]<='9')
        {
            ctoi = 1;
        }
        else if (a[i] == '.' && !hasDecimal)
        {
            ctoi = 1;
            hasDecimal = 1;
            dot=i;
        }
        else if (a[i]=='-')
        {
            flag=1;
        }
        else
        {
            ctoi = 0;
        }
        if (befctoi == 0 && ctoi == 1) // ������
        {
            wei[count] = a[i] - '0';
            befctoi = 1;
            count++;
        }
        else if (befctoi == 1 && ctoi == 1) // ��λ
        {
            wei[count] = a[i] - '0';
            count++;
        }
        else if (befctoi == 1 && ctoi == 0) // �½���
        {
            double decimalMultiplier = 1.0;
            double decimalNum = 0.0;
            for (j = 0; j < count; j++)
            {
                if (hasDecimal && a[i - count + j] == '.')
                {
                    decimalMultiplier = pow(10, count - j - 1);

                }
                else
                {
                    if (!hasDecimal)
                    {
                        num[times] += wei[j] * pow(10, count - j - 1);
                    }
                    else
                    {
                        if(i - count + j+1 <=dot)
                            decimalNum += wei[j] * pow(10, count - j -2);//С����ǰ
                        else  if(i - count + j+1 >dot)
                            decimalNum += wei[j] * pow(10, count - j -1);//С�����

                    }
                }
            }
            if (hasDecimal)
            {
                num[times]+= decimalNum / decimalMultiplier;
            }
            if (flag==1) num[times]*=-1;
            times++;
            befctoi = 0;
            count = 0;
            hasDecimal = 0;
            flag = 0;
        }
    }

    for (i = 0; i < times; i++)number[i]=num[i];
}

void analysis_plus(char *a, double *number)
{
    int len = strlen(a), i, j, count = 0, wei[20], times = 0;
    double num[10] = {0};
    int ctoi = 0, befctoi = 0, hasDecimal = 0;
    int isNegative = 0;  // 0��ʾ������1��ʾ����

    for (i = 0; i < len + 1; i++) {
      if (a[i] >= '0' && a[i] <= '9') {
        ctoi = 1;
      } else if (a[i] == '.' && !hasDecimal) {
        ctoi = 1;
        hasDecimal = 1;
      } else if (a[i] == '-' && i == 0 && !befctoi) {
        isNegative = 1;
        ctoi = 1;
      } else {
        ctoi = 0;
      }

      if (befctoi == 0 && ctoi == 1) {  // ������
        if (a[i] == '-') {
          isNegative = 1;
        } else {
          wei[count] = a[i] - '0';
          befctoi = 1;
          count++;
        }
      } else if (befctoi == 1 && ctoi == 1) {  // ��λ
        wei[count] = a[i] - '0';
        count++;
      } else if (befctoi == 1 && ctoi == 0) {  // �½���
        double decimalMultiplier = 1.0;
        double decimalNum = 0.0;
        for (j = 0; j < count; j++) {
          if (hasDecimal && a[i - count + j] == '.') {
            decimalMultiplier = pow(10, count - j - 1);
          } else {
            if (!hasDecimal) {
              num[times] += wei[j] * pow(10, count - j - 1);
            } else {
              if (a[i - count + j + 1] == '.') {
                decimalNum += wei[j] * pow(10, count - j - 2);  // С����ǰ
              } else {
                decimalNum += wei[j] * pow(10, count - j - 1);  // С�����
              }
            }
          }
        }
        if (hasDecimal) {
          num[times] += decimalNum / decimalMultiplier;
        }
        if (isNegative) {
          num[times] = -num[times];
          isNegative = 0;
        }
        times++;
        befctoi = 0;
        count = 0;
        hasDecimal = 0;
      }
    }

    for (i = 0; i < times; i++) {
      number[i] = num[i];
    }
}
