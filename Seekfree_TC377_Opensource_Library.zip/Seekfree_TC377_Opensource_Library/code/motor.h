/*
 * motor.h
 *
 *  Created on: 2023��11��18��
 *      Author: 21035
 */

#ifndef CODE_MOTOR_H_
#define CODE_MOTOR_H_

#include "zf_common_headfile.h"

void  motor_encoder_init(void);
void motor_drive(int a,int b,int c);

#endif /* CODE_MOTOR_H_ */
