/*
 * pid.h
 *
 *  Created on: 2023��11��18��
 *      Author: 21035
 */

#ifndef CODE_PID_H_
#define CODE_PID_H_

#include "kalman.h"

typedef volatile struct
{
    float Kp,Ki,Kd;    //���������֣�΢��ϵ��
    float target_val;  //Ŀ��ֵ
    float actual_val;  //ʵ��ֵ
    float err;         //��ǰƫ��
    float err_last;    //�ϴ�ƫ��
    float err_sum;     //����ۼ�ֵ
    float output;      //���
}tPid;

extern tPid X_Balance,Y_Balance,X_Velocity,Y_Velocity;
extern tPid rollpid,gyroxpid,leftpid,rightpid,pitchpid,gyroypid,encoderpid,gyrozpid,yawpid,errorpid;

void Pid_Init(double xb_p,double xb_i,double xb_d,double yb_p,double yb_i,double yb_d,double yv_p,double yv_i);
float x_balance(float Angle,float Angle_Zero,float Gyro);
float y_balance(float Angle,float Angle_Zero,float Gyro);
float y_velocity(int encoder,int encoder_zero);

float constrain_float(float amt, float low, float high);
int constrain_int(int amt, int low, int high);
int emergency_stop (float real_roll,float pitch,float real_pitch,float roll);

#endif /* CODE_PID_H_ */
