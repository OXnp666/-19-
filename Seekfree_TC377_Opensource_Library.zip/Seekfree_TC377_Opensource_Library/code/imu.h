/*
 * imu.h
 *
 *  Created on: 2024��6��7��
 *      Author: 21035
 */

#ifndef CODE_IMU_H_
#define CODE_IMU_H_

#include <all_data.h>
#include <mymath.h>

extern float GyroOffset_Xdata;
extern float GyroOffset_Ydata;
extern float GyroOffset_Zdata;
extern float GyroOffset_Xdata, icm_data_acc_x, icm_data_gyro_x;
extern float GyroOffset_Ydata, icm_data_acc_y, icm_data_gyro_y;
extern float GyroOffset_Zdata, icm_data_acc_z, icm_data_gyro_z;

void gyroOffset_init(void);
void ICM_getEulerianAngles(void);
extern float eulerAngle_yaw, eulerAngle_pitch, eulerAngle_roll, eulerAngle_yaw_total, test,test1,test2,test3;
void Nav_Loop(uint8 mode);
void Nav_Start(void);
uint8 Nav_Check(double n);
void Nav_Set(double x,double y);

#endif /* CODE_IMU_H_ */
