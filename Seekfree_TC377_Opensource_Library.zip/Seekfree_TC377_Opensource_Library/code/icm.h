/*
 * icm.h
 *
 *  Created on: 2023��11��17��
 *      Author: 21035
 */

#ifndef CODE_ICM_H_
#define CODE_ICM_H_

#include <all_data.h>
#include <mymath.h>
#include <math.h>
#include <kalman.h>

extern void IcmGetAngle(const _st_Mpu *pMpu,_st_AngE *pAngE, float dt);
extern void IcmGetOffset(void);
extern void IcmGetData(void);

#endif /* CODE_ICM_H_ */
