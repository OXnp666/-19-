/*
 * key.h
 *
 *  Created on: 2023��11��27��
 *      Author: 21035
 */

#ifndef CODE_KEY_H_
#define CODE_KEY_H_

#include "zf_common_headfile.h"

void mykey_init(void);
void key_scan(void);
uint8 key_read(void);

#endif /* CODE_KEY_H_ */
