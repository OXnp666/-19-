/*
 * kalman.h
 *
 *  Created on: 2023��11��17��
 *      Author: 21035
 */

#ifndef CODE_KALMAN_H_
#define CODE_KALMAN_H_

#include <math.h>
#include <stdint.h>

struct _1_ekf_filter
{
    float LastP;
    float   Now_P;
    float out;
    float Kg;
    float Q;
    float R;
};

//void ekf_1(struct EKF *ekf,void *input);  //һά������
extern void kalman_1(struct _1_ekf_filter *ekf,float input);  //һά������
int low_1_left(int encoder); //һ�׵�ͨ
int low_1_right(int encoder);
int low_1_stand(int encoder);

#endif /* CODE_KALMAN_H_ */
