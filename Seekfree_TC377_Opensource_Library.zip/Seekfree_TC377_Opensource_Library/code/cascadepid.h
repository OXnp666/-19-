/*
 * cascadepid.h
 *
 *  Created on: 2023��11��29��
 *      Author: 21035
 */

#ifndef CODE_CASCADEPID_H_
#define CODE_CASCADEPID_H_

#include "pid.h"

void circlepid_init(double gyx_kp,double roll_kp,double speed_kp,double gyy_kp,double pitch_kp,double encoder_kp,double encoder_ki,double speed_kd);
void turnpid_init(double gyz_kp,double error_kp,double error_ki);
void PID_caculate(tPid * pid,float actual_val,float target_val);
void I_limit(tPid * pid, float low, float high);


#endif /* CODE_CASCADEPID_H_ */
