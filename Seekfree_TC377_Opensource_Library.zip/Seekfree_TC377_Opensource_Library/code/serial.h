/*
 * serial.h
 *
 *  Created on: 2023��11��20��
 *      Author: 21035
 */

#ifndef CODE_SERIAL_H_
#define CODE_SERIAL_H_

#include "zf_common_headfile.h"
#include "all_data.h"
#include "stdio.h"
#include "stdarg.h"
#include "string.h"
#include <stdlib.h>
#include <math.h>

void analysis(char *a,double *number);
void analysis_plus(char *a,double *number);

#endif /* CODE_SERIAL_H_ */
