/*
 * pid.h
 *
 *  Created on: 2024��1��12��
 *      Author: 123
 */

#ifndef CODE_PID_H_
#define CODE_PID_H_

typedef struct
{
    float                kp;         //P
    float                ki;         //I
    float                kd;         //D
    float                imax;       //�����޷�

    float                out_p;  //KP���
    float                out_i;  //KI���
    float                out_d;  //KD���
    float                out;    //pid���

    float                integrator; //< ����ֵ
    float                last_error; //< �ϴ����
    float                last_derivative;//< �ϴ���������ϴ����֮��
    unsigned long        last_t;     //< �ϴ�ʱ��
}pid_param_t;

extern pid_param_t P_acc_pid;
extern pid_param_t P_angle_pid;
extern pid_param_t P_vel_pid;
extern pid_param_t R_acc_pid;
extern pid_param_t R_angle_pid;
extern pid_param_t R_vel_pid;
extern pid_param_t Y_acc_pid;
extern pid_param_t Y_angle_pid;
extern pid_param_t Y_vel_pid;

void R_Acc_Pid_Init(pid_param_t * pid);
void R_Angle_Pid_Init(pid_param_t * pid);
void R_Vel_Pid_Init(pid_param_t * pid);//�ٶȻ�
void P_Acc_Pid_Init(pid_param_t * pid);
void P_Angle_Pid_Init(pid_param_t * pid);
void P_Vel_Pid_Init(pid_param_t * pid);//�ٶȻ�
void Y_Acc_Pid_Init(pid_param_t * pid);
void Y_Angle_Pid_Init(pid_param_t * pid);
void Y_Vel_Pid_Init(pid_param_t * pid);//�ٶȻ�
float Y_Cascade_Pid_Ctrl(float yaw);
float R_Cascade_Pid_Ctrl(float zhongzhi,int V_AB);
float P_Cascade_Pid_Ctrl(float zhongzhi, int V_C);

float constrain_float(float amt, float low, float high);
short constrain_short(short amt, short low, short high);
short constrain_double(double amt, double low, double high);
int32 constrain_int(const int32 amt, int32 low, int32 high);
float PidLocCtrl(pid_param_t * pid, float error);
#endif /* CODE_PID_H_ */
