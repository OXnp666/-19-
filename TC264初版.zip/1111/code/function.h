/*
 * function.h
 *
 *  Created on: 2024��1��14��
 *      Author: 123
 */

#ifndef CODE_FUNCTION_H_
#define CODE_FUNCTION_H_
#define VOLTAGE_PORT    ADC0_CH8_A8 // ������˿�

extern uint16 valtage_adc;
extern float valtage_now;


void BUZZ_Di(uint32 LV);
void battery(void);
#endif /* CODE_FUNCTION_H_ */
