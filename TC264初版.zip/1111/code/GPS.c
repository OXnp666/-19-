/*
 * GPS.c
 *
 *  Created on: 2024��1��18��
 *      Author: 123
 */


#include "zf_common_headfile.h"
#include <GPS.h>

#define FILTER_X    20              //һ�δ���죬ƽ���˲�

my_gps_data new_gps_data;

double nancei_1 = 0;
double nancei_2 = 0;
double lati[pointsum];                    //γ��
double longi[pointsum];                   //����
double yaw_value,                         //GPS�����
       latitude_value,                    //γ��
       longitude_value;                   //����
float GPS_distance_1 = 0;
float GPS_distance_2 = 0;
float min_dist = 1.5;                   //�л�����һ������С����
uint8 N = 1;
uint8 save_flag = 0;
uint8 run_flag = 0;
int16 GPS_P = 0;
int16 vlog = 0;



float Filter(float adult[], int8 x)            //ȥ���ֵ��Сֵ��ƽ��ֵ
{
    int i, j;
    float filter_temp, filter_sum = 0;
    float filter_buf[25];
    for(i = 0; i < x; i++)
    {
      filter_buf[i] = adult[i];
    }
    // ����ֵ��С�������У�ð�ݷ���
    for(j = 0; j < x - 1; j++) {
      for(i = 0; i < x - 1 - j; i++) {
        if(filter_buf[i] > filter_buf[i + 1]) {
          filter_temp = filter_buf[i];
          filter_buf[i] = filter_buf[i + 1];
          filter_buf[i + 1] = filter_temp;
        }
      }
    }
    // ȥ�������С��ֵ����ƽ��
    for(i = 1; i < x - 1; i++) filter_sum += filter_buf[i];
    return filter_sum / (x - 2);
}

void save_point_code(void)
{
    nancei_1 = 0;
    nancei_2 = 0;
    while(N)                              //����ѭ��
    {
        if(gps_tau1201_flag && GPS_P <= pointsum)
        {
           gps_tau1201_flag = 0;
           gps_data_parse();

           if(gps_tau1201.latitude != 0)
           {
             nancei_1 = nancei_1 + gps_tau1201.latitude;
             nancei_2 = nancei_2 + gps_tau1201.longitude;
             vlog++;
           }

        }
       if(vlog == FILTER_X)
       {
         vlog = 0;
         N = 0;                            //�˳�ѭ��
       }

    }
}



void key_location(void)
{
    if(key3_flag == 1)
    {
        key3_flag = 0;//ʹ�ð���֮��Ӧ�������־
        N = 1;
        save_point_code();
        longi[GPS_P] = nancei_2 / FILTER_X;
        lati[GPS_P]  = nancei_1 / FILTER_X;
        GPS_P++;
        BUZZ_Di(100);
        if(GPS_P == pointsum)
        {
            save_flag = 1;
            GPS_P = 0;
            BUZZ_Di(100);
        }
    }
}

void get_value(void)
{

    if(gps_tau1201_flag )
    {
       gps_tau1201_flag = 0;
       gps_data_parse();     //��ʼ��������
       yaw_value        = gps_tau1201.direction;
       latitude_value   = gps_tau1201.latitude;
       longitude_value  = gps_tau1201.longitude;
       GPS_distance_1   = get_two_points_distance(latitude_value,longitude_value,lati[GPS_P],longi[GPS_P]);
       GPS_distance_2   = get_two_points_distance(latitude_value,longitude_value,lati[GPS_P+1],longi[GPS_P+1]);
       new_gps_data.point_angle = get_two_points_azimuth(latitude_value,longitude_value,lati[GPS_P],longi[GPS_P]);

    //�ж����������Ƿ��ڳ�ͷ��Ŀ�귽���м䣬���ǶȽ���



        if(GPS_distance_1 <= min_dist)
        {
           GPS_P += 1;

        }
        else if(GPS_distance_2 <= min_dist && GPS_distance_1 > min_dist)
        {
           GPS_P += 2;
        }


   }



}
