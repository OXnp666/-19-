/*
 * function.c
 *
 *  Created on: 2024��1��14��
 *      Author: 123
 */

#include "zf_common_headfile.h"
#include <function.h>

uint8_t i = 0;
uint16 valtage_adc = 0;
float valtage_now = 0;

void BUZZ_Di(uint32 LV)
{
  gpio_set_level(P33_10, 1);
  system_delay_ms(LV);
  gpio_set_level(P33_10, 0);
}

void battery(void)
{
    valtage_adc = adc_convert(VOLTAGE_PORT);
    valtage_now = 37.32 * valtage_adc / 4096;
    if(valtage_now < 22 && valtage_now > 5)
        BUZZ_Di(1000);
}
