/*
 * pid.c
 *
 *  Created on: 2024��1��12��
 *      Author: 123
 */

#include "zf_common_headfile.h"
#include <pid.h>
pid_param_t R_acc_pid;
pid_param_t R_angle_pid;
pid_param_t R_vel_pid;

pid_param_t P_acc_pid;
pid_param_t P_angle_pid;
pid_param_t P_vel_pid;

pid_param_t Y_acc_pid;             //yaw���ٶȻ�PID��ʼ��
pid_param_t Y_angle_pid;           //yaw�ǶȻ�PID��ʼ��
pid_param_t Y_vel_pid;             //yaw�ٶȻ���ʼ��


/*!
  * @brief    �޷�����
  *
  * @param    amt   �� ����
  * @param    low   �� ���ֵ
  * @param    high  �� ���ֵ
  *
  * @return   ��
  *
  * @note     ��
  *
  * @see      ��
  *
  * @date     2020/6/8
  */
float constrain_float(float amt, float low, float high)
{
    return ((amt)<(low)?(low):((amt)>(high)?(high):(amt)));
}

short constrain_short(short amt, short low, short high)
{
    return ((amt)<(low)?(low):((amt)>(high)?(high):(amt)));
}

short constrain_double(double amt, double low, double high)
{
    return ((amt)<(low)?(low):((amt)>(high)?(high):(amt)));
}

int32 constrain_int(const int32 amt, int32 low, int32 high)
{
    return ((amt)<(low)?(low):((amt)>(high)?(high):(amt)));
}



float R_Cascade_Pid_Ctrl(float zhongzhi,int V_AB)
{
    static int16_t Pid_t;
    Pid_t = Pid_t + 1;

    if(Pid_t % 10 == 0)
    {
        Pid_t = 0;
        A_encoder_data = -encoder_get_count(A_FLYWHEEL_ENCODER_INDEX);      // ��ȡA�������ֵ
        B_encoder_data = encoder_get_count(B_FLYWHEEL_ENCODER_INDEX);      // ��ȡA�������ֵ
        encoder_clear_count(A_FLYWHEEL_ENCODER_INDEX);                               // ������������� �����´βɼ�
        encoder_clear_count(B_FLYWHEEL_ENCODER_INDEX);                               // ������������� �����´βɼ�

        PidLocCtrl(&R_vel_pid, (float)(V_AB + A_encoder_data + B_encoder_data));//�ٶȻ�
    }
    if(Pid_t % 5 == 0)
    {
        PidLocCtrl(&R_angle_pid, R_vel_pid.out + (eulerAngle.roll - zhongzhi));//�ǶȻ�
    }

    PidLocCtrl(&R_acc_pid, R_angle_pid.out + imu_data.gyro_x * 940);  //���ٶȻ�
                         //R_angle_pid.out

    return R_acc_pid.out;
}


float P_Cascade_Pid_Ctrl(float zhongzhi, int V_C)
{
    static int16_t Pid_t;
    Pid_t = Pid_t+2;
    if(Pid_t % 10 == 0)
    {
        Pid_t = 0;
        C_encoder_data  = encoder_get_count(C_ENCODER_INDEX);      // ��ȡA�������ֵ
        encoder_clear_count(C_ENCODER_INDEX);                               // ������������� �����´βɼ�
        PidLocCtrl(&P_vel_pid, (float)(C_encoder_data-V_C));   //�ٶȻ��������ٶ�Ϊ0
    }
    if(Pid_t % 5 == 0)
        PidLocCtrl(&P_angle_pid,-P_vel_pid.out - eulerAngle.pitch + zhongzhi);//�ǶȻ�

        PidLocCtrl(&P_acc_pid,P_angle_pid.out-(imu_data.gyro_y *940) );  //���ٶȻ�

    return P_acc_pid.out;
}
float Y_Cascade_Pid_Ctrl(float Error)
{
    static int16_t Pid_t;
    Pid_t = Pid_t + 1;
    if(Pid_t % 25 == 0){
        Pid_t = 0;
        PidLocCtrl(&Y_angle_pid, Error);  //�ǶȻ�
    }
    if(Pid_t % 8 == 0){
        PidLocCtrl(&Y_acc_pid, Y_angle_pid.out - imu_data.gyro_z);  //���ٶȻ�
    }
    return Y_acc_pid.out;
}
/*!
  * @brief    pidλ��ʽ���������
  *
  * @param    pid     pid����
  * @param    error   pid�������
  *
  * @return   PID������
  *
  * @note     ��
  *
  * @see      ��
  *
  * @date     2020/6/8
  */
float PidLocCtrl(pid_param_t * pid, float error)
{

     //�ۻ����
    pid->integrator += error;

     //����޷�
    constrain_float(pid->integrator, -pid->imax, pid->imax);


    pid->out_p = pid->kp * error;
    pid->out_i = pid->ki * pid->integrator;
    pid->out_d = pid->kd * (error - pid->last_error);

    pid->last_error = error;

    pid->out = pid->out_p + pid->out_i + pid->out_d;


    return pid->out;
}


void R_Acc_Pid_Init(pid_param_t * pid)//���ٶȻ�
{
    pid->kp        = 8.82;            //seekfree_assistant_parameter[0]; //13
    pid->ki        = 0;
    pid->kd        = 0;
    pid->imax      = 100;
    pid->out_p     = 0;
    pid->out_i     = 0;
    pid->out_d     = 0;
    pid->out       = 0;
    pid->integrator= 0;
    pid->last_error= 0;
    pid->last_derivative   = 0;
    pid->last_t    = 0;
}
void R_Angle_Pid_Init(pid_param_t * pid)//�ǶȻ�
{
    pid->kp        = 330;             //seekfree_assistant_parameter[1];//35
    pid->ki        = 0;
    pid->kd        = 0.0;
    pid->imax      = 50;
    pid->out_p     = 0;
    pid->out_i     = 0;
    pid->out_d     = 0;
    pid->out       = 0;
    pid->integrator= 0;
    pid->last_error= 0;
    pid->last_derivative   = 0;
    pid->last_t    = 0;
}
void R_Vel_Pid_Init(pid_param_t * pid)//�ٶȻ�
{

    pid->kp        = 0.033;             //seekfree_assistant_parameter[2];
    pid->ki        = 0.0;
    pid->kd        = 0.000;
    pid->imax      = 0.0;
    pid->out_p     = 0;
    pid->out_i     = 0;
    pid->out_d     = 0;
    pid->out       = 0;
    pid->integrator= 0;
    pid->last_error= 0;
    pid->last_derivative   = 0;
    pid->last_t    = 0;
}

void P_Acc_Pid_Init(pid_param_t * pid)//���ٶ�
{
    pid->kp        = 0.72;               //seekfree_assistant_parameter[3]; //0.7    0.9
    pid->ki        = 0;
    pid->kd        = 0;
    pid->imax      = 100;
    pid->out_p     = 0;
    pid->out_i     = 0;
    pid->out_d     = 0;
    pid->out       = 0;
    pid->integrator= 0;
    pid->last_error= 0;
    pid->last_derivative   = 0;
    pid->last_t    = 0;
}
void P_Angle_Pid_Init(pid_param_t * pid)//�ǶȻ�
{
    pid->kp        = 350;               //seekfree_assistant_parameter[4];//130  158
    pid->ki        = 0.0;
    pid->kd        = 0;
    pid->imax      = 50;
    pid->out_p     = 0;
    pid->out_i     = 0;
    pid->out_d     = 0;
    pid->out       = 0;
    pid->integrator= 0;
    pid->last_error= 0;
    pid->last_derivative   = 0;
    pid->last_t    = 0;
}
void P_Vel_Pid_Init(pid_param_t * pid)//�ٶȻ�
{

    pid->kp        = 0.033;               //seekfree_assistant_parameter[5];                       //seekfree_assistant_parameter[6];//0.038   0.031
    pid->ki        = 0.0;
    pid->kd        = 0.0;
    pid->imax      = 0.0;
    pid->out_p     = 0;
    pid->out_i     = 0;
    pid->out_d     = 0;
    pid->out       = 0;
    pid->integrator= 0;
    pid->last_error= 0;
    pid->last_derivative   = 0;
    pid->last_t    = 0;
}

void Y_Acc_Pid_Init(pid_param_t * pid)//���ٶȻ�
{
    pid->kp        = 492;         //seekfree_assistant_parameter[0];//500
    pid->ki        = 0;
    pid->kd        = 0;           //seekfree_assistant_parameter[1];
    pid->imax      = 100;
    pid->out_p     = 0;
    pid->out_i     = 0;
    pid->out_d     = 0;
    pid->out       = 0;
    pid->integrator= 0;
    pid->last_error= 0;
    pid->last_derivative   = 0;
    pid->last_t    = 0;
}
void Y_Angle_Pid_Init(pid_param_t * pid)//�ǶȻ�
{
    pid->kp        = 0.029;          //seekfree_assistant_parameter[2];//0.03
    pid->ki        = 0;             //seekfree_assistant_parameter[3];
    pid->kd        = 0;             //seekfree_assistant_parameter[4];
    pid->imax      = 1000;
    pid->out_p     = 0;
    pid->out_i     = 0;
    pid->out_d     = 0;
    pid->out       = 0;
    pid->integrator= 0;
    pid->last_error= 0;
    pid->last_derivative   = 0;
    pid->last_t    = 0;
}
void Y_Vel_Pid_Init(pid_param_t * pid)//�ٶȻ�
{

    pid->kp        = 0;             //seekfree_assistant_parameter[5];
    pid->ki        = 0;             //seekfree_assistant_parameter[6];
    pid->kd        = 0;             //seekfree_assistant_parameter[7];
    pid->imax      = 70000;
    pid->out_p     = 0;
    pid->out_i     = 0;
    pid->out_d     = 0;
    pid->out       = 0;
    pid->integrator= 0;
    pid->last_error= 0;
    pid->last_derivative   = 0;
    pid->last_t    = 0;
}
