/*
 * key.h
 *
 *  Created on: 2024��1��13��
 *      Author: 123
 */

#ifndef CODE_KEY_H_
#define CODE_KEY_H_

#define KEY1    P20_9
#define KEY2    P20_8
#define KEY3    P20_7
#define KEY4    P20_6

extern int key1_flag;
extern int key2_flag;
extern int key3_flag;
extern int key4_flag;
extern int key5_flag;



void  Key_Scan_Deal (void);
void keyinit(void);
#endif /* CODE_KEY_H_ */
