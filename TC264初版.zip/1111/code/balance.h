/*
 * balance.h
 *
 *  Created on: 2024��1��12��
 *      Author: 123
 */

#ifndef CODE_BALANCE_H_
#define CODE_BALANCE_H_

typedef struct{
        float Yaw_Zero;

        float Roll_Zero;
        float Roll_error;

        float Pitch_Zero;
        float Pitch_error;
        float Pitch_Value;


}Car_zero;

typedef struct{

        Car_zero    Car_Zero;       //�������

}Car_Price_Typedef;

extern Car_Price_Typedef Car_Price;
extern double Direction_Error;     //����ƫ��
extern double already_Angle;
extern int speed;


void Balance(void);

#endif /* CODE_BALANCE_H_ */
