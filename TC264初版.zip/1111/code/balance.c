/*
 * balance.c
 *
 *  Created on: 2024��1��12��
 *      Author: 123
 */

#include "zf_common_headfile.h"
#include <balance.h>
Car_Price_Typedef Car_Price;
int16 PWM_R = 0, PWM_Y = 0, PWM_P = 0;                       //PWM�м���
//float Yaw_Zero=0.0, Yaw_Run = 0;                     //XY��Ƕ���㣬���е�йأ�Ӱ���ȶ���
float Roll_error = 0, Pitch_error = 0, Yaw_error = 0;
double Direction_Error;     //����ƫ��
double already_Angle = 0;       //�Ѿ�ת�˵ĽǶ�
int speed = 0;

void Balance(void)
{
    PWM_R = (int16)R_Cascade_Pid_Ctrl(Car_Price.Car_Zero.Roll_Zero , 0);
    PWM_P = (int16)P_Cascade_Pid_Ctrl(Car_Price.Car_Zero.Pitch_Zero , speed);
    PWM_Y = (int32)Y_Cascade_Pid_Ctrl( Direction_Error);
   // Direction_Error = eulerAngle.yaw - already_Angle;
    /*************************����******************************************************************************************************************************/
    Car_Price.Car_Zero.Roll_error = eulerAngle.pitch - Car_Price.Car_Zero.Roll_Zero;
    Car_Price.Car_Zero.Pitch_error = eulerAngle.roll - Car_Price.Car_Zero.Pitch_Zero;
    //�����ض��Ƕ�ֹͣ����
    if(func_abs(Car_Price.Car_Zero.Roll_error) > 30 || func_abs(Car_Price.Car_Zero.Pitch_error) > 30)
    {
       //��ģˤ�����������

       motorkey = 0;

    }
    M_Control(PWM_R + PWM_Y, - PWM_R + PWM_Y, - PWM_P);

}
