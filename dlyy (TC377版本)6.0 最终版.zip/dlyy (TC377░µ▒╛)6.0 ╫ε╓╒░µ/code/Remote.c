/*
 * Remote.c
 *
 *  Created on: 2024��5��4��
 *      Author: ŷ��
 */
#include "Remote.h"
/*
 * ���ҡ�� �����ٶ�
 * �ұ�ҡ�� ����ת��
 *
 *
 *
 *
 */

st_Remote_Para RemotePara={
        .Remote_Mode = OFF,
        .Stop = OFF,
        .Turn_PWM_Max=2000,
        .Turn_PWM_Min=-2000,
        .Speed_Set_Max = 2000,
        .Speed_Set_Min = -2000,

};


void Remote_Control_Deal(void)
{
    static unsigned int change_count1 = 0,change_count2 =1;
          if (lora3a22_state_flag == 1)
          {
              if (lora3a22_finsh_flag == 1)
              {

                  /******ת�����*******/
                  //�ұ�ҡ������ֵ
                  RemotePara.Last_Turn_PWM = RemotePara.Turn_PWM;
                  RemotePara.Turn_PWM = lora3a22_uart_transfer.joystick[2];

                  RemotePara.Turn_PWM = (signed short)range_protect(RemotePara.Turn_PWM,  RemotePara.Turn_PWM_Min,  RemotePara.Turn_PWM_Max);//���Ʒ���




                  /*****�ٶȻ�����***********/
                  //���ҡ������ֵ
                  RemotePara.Last_Speed_Set =  RemotePara.Speed_Set;
                  RemotePara.Speed_Set = lora3a22_uart_transfer.joystick[1];

                  RemotePara.Speed_Set = (signed short)range_protect( RemotePara.Speed_Set,RemotePara.Speed_Set_Min,  RemotePara.Speed_Set_Max);//���Ʒ���


                  //��˽���
                  if(RemotePara.Remote_Mode == OFF
                   && lora3a22_uart_transfer.joystick[0]<0
                   &&lora3a22_uart_transfer.joystick[2] >0 )
                  {
                      change_count1++;
                  }
                  if(change_count1 >10)
                  {
                      BUZZ_DiDiDi(20);
                      change_count1 = 0;
                      RemotePara.Remote_Mode = ON;
                  }


                  //�ڰ˽���ͣ��/*
                                    /*if(RemotePara.Stop == OFF
                                     && lora3a22_uart_transfer.joystick[0]<-1500
                                     &&lora3a22_uart_transfer.joystick[2] >1500 )
                                    {
                                        change_count2++;
                                    }
                                    if(change_count2 > 10)
                                    {*/
                                  //      BUZZ_DiDiDi(20);
                                /*        change_count2 = 0;
                                        RemotePara.Stop = ON;
                                        RemotePara.Turn_PWM = 0;
                                        RemotePara.Speed_Set = 0;
                                    }*/




#if 1//�����������Դ򿪴˴�����λ���鿴���͵�����
                  printf ("head = %d\r\n",lora3a22_uart_transfer.head);
                  //lora3a22 ֡ͷ

                  printf ("sum_check = %d\r\n",lora3a22_uart_transfer.sum_check);
                  //lora3a22 ��У��

                  printf ("key0 = %d\r\n",lora3a22_uart_transfer.key[0]);
                  //���ҡ�˰���
                  printf ("key1 = %d\r\n",lora3a22_uart_transfer.key[1]);
                  //�ұ�ҡ�˰���

                  printf ("joystick[0] = %d\r\n",lora3a22_uart_transfer.joystick[0]);
                  //���ҡ������ֵ
                  printf ("joystick[1] = %d\r\n",lora3a22_uart_transfer.joystick[1]);
                  //���ҡ������ֵ
                  printf ("joystick[2] = %d\r\n",lora3a22_uart_transfer.joystick[2]);
                  //�ұ�ҡ������ֵ
                  printf ("joystick[3] = %d\r\n",lora3a22_uart_transfer.joystick[3]);
                  //�ұ�ҡ������ֵ
#endif
                 lora3a22_finsh_flag = 0;
              }
          }
          else
          {
              printf("lora3a22 connection fail \r\n");
          }
          system_delay_ms(50);
}
