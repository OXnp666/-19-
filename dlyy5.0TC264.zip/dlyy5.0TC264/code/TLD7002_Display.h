/*
 * TLD7002_Display.h
 *
 *  Created on: 2024��6��16��
 *      Author: �����Ƽ�������~QQ 2123687044
 */

#ifndef CODE_TLD7002_DISPLAY_H_
#define CODE_TLD7002_DISPLAY_H_
#include "zf_common_headfile.h"
#include "zf_device_tld7002.h"
#include "zf_device_dot_matrix_screen.h"


extern void  TLD_Display_Task();
void display_example1(void);
void display_example2(void);
void display_example3(void);
void display_example4(void);


extern uint32      stime;



#endif /* CODE_TLD7002_DISPLAY_H_ */
