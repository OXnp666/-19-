#ifndef _GPS_H_
#define _GPS_H_
#include "zf_common_headfile.h"
#include "PLATFORM_TYPES.H"
#include "zf_common_typedef.h"
#define KEY1 P20_8
#define pointsum 15

#define Limit_Min_Max(data, min, max)   ((data > max) ? max:((data < min) ? min:data))



extern int GPS_Index;

extern short GPS_Error;
extern float Angle_dev;
extern float Dir, Latitude, Longitude;

extern double Lati_Filter[pointsum];
extern double Longi_Filter[pointsum];

extern uint32 Lati_Final[pointsum];
extern uint32 Longi_Final[pointsum];

void BUZZ_Di(uint32 LV);
void save_point_code(void);
void save(void);
void get_value(void);
double angle_diff(double a, double b);
void GPS_Data_Display(void);
void GPS_Key_Scan_Deal(void);
void GPS_process(short *error);

#endif
