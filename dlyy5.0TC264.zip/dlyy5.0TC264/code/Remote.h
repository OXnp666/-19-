#ifndef __REMOTE_H__
#define __REMOTE_H__
#include "System.h"


typedef struct
{
    signed short int Turn_PWM;
    signed short int Last_Turn_PWM;
    signed short int Turn_PWM_Min;
    signed short int Turn_PWM_Max;

    signed short int Speed_Set;
    signed short int Last_Speed_Set;
    signed short int Speed_Set_Min;
    signed short int Speed_Set_Max;
    signed short int Stop;
    unsigned char Remote_Mode;  //ң��������ģʽ
} st_Remote_Para;


extern st_Remote_Para RemotePara;

void Remote_Control_Deal(void);





#endif
